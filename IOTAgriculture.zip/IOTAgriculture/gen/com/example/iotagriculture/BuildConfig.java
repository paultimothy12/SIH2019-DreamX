/** Automatically generated file. DO NOT MODIFY */
package com.example.iotagriculture;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}